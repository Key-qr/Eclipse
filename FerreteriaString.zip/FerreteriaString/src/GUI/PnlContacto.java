package GUI;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JEditorPane;

public class PnlContacto extends JPanel implements ActionListener {
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_6;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JButton btnNewButton;
	private JEditorPane editorPane;
	private JLabel lblNewLabel_7;

	/**
	 * Create the panel.
	 */
	public PnlContacto() {
		setBackground(new Color(255, 255, 255));
		setLayout(null);
		
		lblNewLabel = new JLabel("String ArteCodificado;");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Roboto Condensed", Font.BOLD, 55));
		lblNewLabel.setBounds(133, 49, 650, 65);
		add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Para mas información, contactanos:                 ");
		lblNewLabel_1.setBounds(197, 304, 442, 13);
		add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("Nombre:");
		lblNewLabel_2.setBounds(204, 365, 95, 13);
		add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("Apellidos:");
		lblNewLabel_3.setBounds(362, 365, 96, 13);
		add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("Email:");
		lblNewLabel_4.setBounds(525, 365, 64, 13);
		add(lblNewLabel_4);
		
		lblNewLabel_5 = new JLabel("Teléfono:");
		lblNewLabel_5.setBounds(204, 418, 95, 13);
		add(lblNewLabel_5);
		
		lblNewLabel_6 = new JLabel("Comentario:");
		lblNewLabel_6.setBounds(204, 472, 135, 13);
		add(lblNewLabel_6);
		
		textField = new JTextField();
		textField.setBounds(204, 381, 96, 19);
		add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(362, 381, 96, 19);
		add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(525, 381, 96, 19);
		add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(204, 435, 96, 19);
		add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(204, 488, 499, 78);
		add(textField_4);
		textField_4.setColumns(10);
		
		btnNewButton = new JButton("Enviar");
		btnNewButton.addActionListener(this);
		btnNewButton.setBounds(610, 588, 85, 21);
		add(btnNewButton);
		
		editorPane = new JEditorPane();
		editorPane.setFont(new Font("Tahoma", Font.PLAIN, 6));
		editorPane.setContentType("text/html");
		editorPane.setText("""
				<html>
				  <body style='font-family: Arial;'>
				    
				    <p>En <strong>String ArteCodificado</strong>, nos apasiona transformar lo simple en extraordinario. Nos especializamos en la venta de <strong>pinturas seleccionadas</strong>, fusionando diseño, calidad y detalle en cada producto.</p>
				    <p>Nuestro compromiso es ofrecer pinturas únicas que combinen funcionalidad con estilo. Cada pintura ha sido cuidadosamente elegida para asegurar que recibas lo mejor en cada pedido.</p>
				    <p>Gracias por confiar en nosotros.</p>
				  </body>
				</html>
				""");
		editorPane.setEditable(false);
		editorPane.setBounds(120, 119, 668, 170);
		add(editorPane);
		
		lblNewLabel_7 = new JLabel("ENVÍANOS UN MENSAJE, EN BREVE NUESTRO ASSESOR DE VENTAS TE CONTACTARÁ:");
		lblNewLabel_7.setBounds(197, 319, 531, 13);
		add(lblNewLabel_7);
		
		
		
		

	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnNewButton) {
			actionPerformedBtnNewButton(e);
		}
	}
	protected void actionPerformedBtnNewButton(ActionEvent e) {
	    String nombre = textField.getText().trim();
	    String apellido = textField_1.getText().trim();
	    String correo = textField_2.getText().trim();
	    String telefono = textField_3.getText().trim();
	    String comentario = textField_4.getText().trim();

	    if (nombre.equals("") || apellido.equals("") || correo.equals("")|| telefono.equals("") || comentario.equals("")) {
	        JOptionPane.showMessageDialog(
	            this,
	            "Por favor, complete los campos obligatorios: Nombre, Apellido, Email y Comentario.",
	            "Campos incompletos",
	            JOptionPane.ERROR_MESSAGE
	        );
	    } else {
	        JOptionPane.showMessageDialog(
	            this,
	            "Tu mensaje fue enviado con éxito",
	            "Información",
	            JOptionPane.INFORMATION_MESSAGE
	        );
	    }
	}	  
	}

