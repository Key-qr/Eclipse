package GUI;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.border.EmptyBorder;

import Logica.Descuento;

import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PnlDescuentos extends JPanel implements ActionListener {
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JPanel panel_3;
	private JPanel panel_4;
	private JLabel lblNewLabel;
	private JButton btnAplicar;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JTextField txtPorcentaje0;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_6;
	private JLabel lblNewLabel_7;
	private JTextField txtPorcentaje1;
	private JLabel lblNewLabel_8;
	private JLabel lblNewLabel_9;
	private JLabel lblNewLabel_10;
	private JTextField txtPorcentaje2;
	private JLabel lblNewLabel_11;
	private JLabel lblNewLabel_12;
	private JLabel lblNewLabel_13;
	private JTextField txtPorcentaje3;
	private JButton btnRerstaurar;

	/**
	 * Create the panel.
	 */
	public PnlDescuentos() {
		setBackground(new Color(255, 255, 255));
		setLayout(new BorderLayout(0, 0));
		
		panel = new JPanel();
		panel.setBorder(new EmptyBorder(0, 0, 80, 0));
		add(panel, BorderLayout.NORTH);
		
		lblNewLabel = new JLabel("M\u00D3DULO DE DESCUENTOS");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 55));
		panel.add(lblNewLabel);
		
		panel_1 = new JPanel();
		panel_1.setBorder(new EmptyBorder(40, 60, 50, 60));
		add(panel_1, BorderLayout.SOUTH);
		panel_1.setLayout(new GridLayout(0, 2, 0, 0));
		
		btnAplicar = new JButton("APLICAR DESCUENTOS");
		btnAplicar.addActionListener(this);
		btnAplicar.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 16));
		panel_1.add(btnAplicar);
		
		btnRerstaurar = new JButton("RESTAURAR VALORES POR DEFECTO");
		btnRerstaurar.addActionListener(this);
		btnRerstaurar.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 16));
		panel_1.add(btnRerstaurar);
		
		panel_2 = new JPanel();
		panel_2.setBorder(new EmptyBorder(0, 0, 40, 0));
		add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		panel_3 = new JPanel();
		panel_2.add(panel_3, BorderLayout.NORTH);
		
		lblNewLabel_1 = new JLabel("PERSONALIZA LOS DESCUENTOS QUE DAR\u00C1S EN TU TIENDA EN BASE AL MONTO COMPRADO");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_3.add(lblNewLabel_1);
		
		panel_4 = new JPanel();
		panel_4.setBorder(new EmptyBorder(40, 30, 60, 30));
		panel_2.add(panel_4, BorderLayout.CENTER);
		panel_4.setLayout(new GridLayout(4, 4, 0, 0));
		
		lblNewLabel_2 = new JLabel("Menores a S/.100");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_4.add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("Descuento(%):");
		lblNewLabel_4.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_4);
		
		txtPorcentaje0 = new JTextField();
		txtPorcentaje0.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(txtPorcentaje0);
		txtPorcentaje0.setColumns(10);
		
		lblNewLabel_5 = new JLabel("Desde S/.100 a menores de S/.200");
		lblNewLabel_5.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_5);
		
		lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_4.add(lblNewLabel_6);
		
		lblNewLabel_7 = new JLabel("Descuento(%):");
		lblNewLabel_7.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_7);
		
		txtPorcentaje1 = new JTextField();
		txtPorcentaje1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		txtPorcentaje1.setColumns(10);
		panel_4.add(txtPorcentaje1);
		
		lblNewLabel_8 = new JLabel("Desde S/.200 a menores de S/.400");
		lblNewLabel_8.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_8);
		
		lblNewLabel_9 = new JLabel("");
		lblNewLabel_9.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_4.add(lblNewLabel_9);
		
		lblNewLabel_10 = new JLabel("Descuento(%):");
		lblNewLabel_10.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_10);
		
		txtPorcentaje2 = new JTextField();
		txtPorcentaje2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		txtPorcentaje2.setColumns(10);
		panel_4.add(txtPorcentaje2);
		
		lblNewLabel_11 = new JLabel("Desde S/.400 en adelante");
		lblNewLabel_11.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_11);
		
		lblNewLabel_12 = new JLabel("");
		lblNewLabel_12.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_4.add(lblNewLabel_12);
		
		lblNewLabel_13 = new JLabel("Descuento(%):");
		lblNewLabel_13.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_13);
		
		txtPorcentaje3 = new JTextField();
		txtPorcentaje3.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		txtPorcentaje3.setColumns(10);
		panel_4.add(txtPorcentaje3);
		
		
		Descuento.cargarDescuentos();
		
		txtPorcentaje0.setText(String.valueOf(Descuento.porcentaje0));
		txtPorcentaje1.setText(String.valueOf(Descuento.porcentaje1));
		txtPorcentaje2.setText(String.valueOf(Descuento.porcentaje2));
		txtPorcentaje3.setText(String.valueOf(Descuento.porcentaje3));


	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnRerstaurar) {
			actionPerformedBtnRerstaurar(e);
		}
		if (e.getSource() == btnAplicar) {
			actionPerformedBtnAplicar(e);
		}
	}
	protected void actionPerformedBtnAplicar(ActionEvent e) {
		
		try {
			// Pasar los valores de los campos de texto a double
			Descuento.porcentaje0 = Double.parseDouble(txtPorcentaje0.getText());
	        Descuento.porcentaje1 = Double.parseDouble(txtPorcentaje1.getText());
	        Descuento.porcentaje2 = Double.parseDouble(txtPorcentaje2.getText());
	        Descuento.porcentaje3 = Double.parseDouble(txtPorcentaje3.getText());
	        
	        // Mostrar los descuentos en consola    Solo para corroborar
	        System.out.println("Descuento 0: " + Descuento.porcentaje0);
	        System.out.println("Descuento 1: " + Descuento.porcentaje1);
	        System.out.println("Descuento 2: " + Descuento.porcentaje2);
	        System.out.println("Descuento 3: " + Descuento.porcentaje3);
	        
	        // Guardar los descuentos actualizados en el archivo
	        Descuento.guardarDescuentos();

	        // Mostrar mensaje de confirmaci�n
	        
	        
	        JOptionPane.showMessageDialog(null, "Cambios Aplicados", "Información", JOptionPane.INFORMATION_MESSAGE);
	    } catch (NumberFormatException ex) {
	    	// En caso de que el formato no sea v�lido
	        JOptionPane.showMessageDialog(null, "Por favor, ingresa valores numéricos  validos.", "Error", JOptionPane.ERROR_MESSAGE);
	        
	    }
		// Mostrar los descuentos actualizados en un cuadro de di�logo
		JOptionPane.showMessageDialog(null, "Descuento 0: " + Descuento.porcentaje0 + "\n" +
                "Descuento 1: " + Descuento.porcentaje1 + "\n" +
                "Descuento 2: " + Descuento.porcentaje2 + "\n" +
                "Descuento 3: " + Descuento.porcentaje3, 
                "Descuentos Actualizados", JOptionPane.INFORMATION_MESSAGE);
	}
	
	
	protected void actionPerformedBtnRerstaurar(ActionEvent e) {
		Descuento.restaurarValoresPorDefecto();
		Descuento.cargarDescuentos();
        txtPorcentaje0.setText(String.valueOf(Descuento.porcentaje0));
        txtPorcentaje1.setText(String.valueOf(Descuento.porcentaje1));
        txtPorcentaje2.setText(String.valueOf(Descuento.porcentaje2));
        txtPorcentaje3.setText(String.valueOf(Descuento.porcentaje3));
        JOptionPane.showMessageDialog(null, "Cambios cancelados. Se han restaurado los valores guardados.", "Cancelar", JOptionPane.INFORMATION_MESSAGE);
	}
}
