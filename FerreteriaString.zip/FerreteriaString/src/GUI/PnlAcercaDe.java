package GUI;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PnlAcercaDe extends JPanel implements ActionListener {
	private JPanel panel;
	private JPanel panel_1;
	private JLabel lblNewLabel;
	private JPanel panel_2;
	private JPanel panel_3;
	private JPanel panel_4;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private JButton btnCerrarPrograma;

	/**
	 * Create the panel.
	 */
	public PnlAcercaDe() {
		setBackground(new Color(255, 255, 255));
		setLayout(null);
		
		panel = new JPanel();
		panel.setBounds(0, 0, 927, 84);
		add(panel);
		
		lblNewLabel = new JLabel("ACERCA DE LA TIENDA");
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 55));
		panel.add(lblNewLabel);
		
		panel_1 = new JPanel();
		panel_1.setBounds(0, 84, 927, 574);
		panel_1.setBorder(new EmptyBorder(40, 50, 40, 50));
		add(panel_1);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		panel_2 = new JPanel();
		panel_1.add(panel_2, BorderLayout.NORTH);
		panel_2.setLayout(new GridLayout(0, 1, 0, 0));
		
		lblNewLabel_1 = new JLabel("AUTORES");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 40));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblNewLabel_1);
		
		panel_3 = new JPanel();
		panel_3.setBorder(new EmptyBorder(0, 150, 0, 150));
		panel_1.add(panel_3, BorderLayout.SOUTH);
		panel_3.setLayout(new GridLayout(0, 1, 0, 0));
		
		btnCerrarPrograma = new JButton("CERRAR PROGRAMA");
		btnCerrarPrograma.addActionListener(this);
		btnCerrarPrograma.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 16));
		panel_3.add(btnCerrarPrograma);
		
		panel_4 = new JPanel();
		panel_4.setBorder(new EmptyBorder(100, 0, 100, 0));
		panel_1.add(panel_4, BorderLayout.CENTER);
		panel_4.setLayout(new GridLayout(0, 1, 0, 0));
		
		lblNewLabel_2 = new JLabel("MANUEL BULNES MENDOZA");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 24));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		panel_4.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("MIGUEL ROJAS SANTIVAÑEZ");
		lblNewLabel_3.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 24));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		panel_4.add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("KEYSI QUIÑE REBAZA");
		lblNewLabel_4.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 24));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		panel_4.add(lblNewLabel_4);
		
		lblNewLabel_5 = new JLabel("ROBERT JIMENEZ PAUCAR");
		lblNewLabel_5.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 24));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		panel_4.add(lblNewLabel_5);
		
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnCerrarPrograma) {
			actionPerformedBtnCerrarPrograma(e);
		}
	}
	protected void actionPerformedBtnCerrarPrograma(ActionEvent e) {
		System.exit(0);
	}
}
