package GUI;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Logica.Obsequio;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PnlObsequios extends JPanel implements ActionListener {
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JLabel lblNewLabel;
	private JButton btnAceptar;
	private JPanel panel_3;
	private JPanel panel_4;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JTextField txtObsequio0;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_6;
	private JLabel lblNewLabel_7;
	private JTextField txtObsequio1;
	private JLabel lblNewLabel_8;
	private JLabel lblNewLabel_9;
	private JLabel lblNewLabel_10;
	private JTextField txtObsequio2;
	private JLabel lblNewLabel_11;
	private JLabel lblNewLabel_12;
	private JLabel lblNewLabel_13;
	private JTextField txtObsequio3;
	private JButton btnRestaurar;

	/**
	 * Create the panel.
	 */
	public PnlObsequios() {
		setBackground(new Color(255, 255, 255));
		setLayout(new BorderLayout(0, 0));
		
		panel = new JPanel();
		panel.setBorder(new EmptyBorder(0, 0, 80, 0));
		add(panel, BorderLayout.NORTH);
		panel.setLayout(new GridLayout(0, 1, 0, 0));
		
		lblNewLabel = new JLabel("M\u00D3DULO DE OBSEQUIOS");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 55));
		panel.add(lblNewLabel);
		
		panel_1 = new JPanel();
		panel_1.setBorder(new EmptyBorder(40, 60, 50, 60));
		add(panel_1, BorderLayout.SOUTH);
		panel_1.setLayout(new GridLayout(0, 2, 0, 0));
		
		btnAceptar = new JButton("APLICAR OBSEQUIOS");
		btnAceptar.addActionListener(this);
		btnAceptar.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 16));
		panel_1.add(btnAceptar);
		
		btnRestaurar = new JButton("RESTAURAR VALORES POR DEFECTO");
		btnRestaurar.addActionListener(this);
		btnRestaurar.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 16));
		panel_1.add(btnRestaurar);
		
		panel_2 = new JPanel();
		panel_2.setBorder(new EmptyBorder(0, 0, 40, 0));
		add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		panel_3 = new JPanel();
		panel_2.add(panel_3, BorderLayout.NORTH);
		
		lblNewLabel_1 = new JLabel("PERSONALIZA LOS OBSEQUIOS QUE DAR\u00C1S EN TU TIENDA EN BASE AL MONTO COMPRADO");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_3.add(lblNewLabel_1);
		
		panel_4 = new JPanel();
		panel_4.setBorder(new EmptyBorder(40, 30, 60, 30));
		panel_2.add(panel_4, BorderLayout.CENTER);
		panel_4.setLayout(new GridLayout(4, 4, 0, 0));
		
		lblNewLabel_2 = new JLabel("Menores a S/.100");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("Obsequio:");
		lblNewLabel_4.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_4);
		
		txtObsequio0 = new JTextField();
		txtObsequio0.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(txtObsequio0);
		txtObsequio0.setColumns(10);
		
		lblNewLabel_5 = new JLabel("Desde S/.100 a menores de S/.200");
		lblNewLabel_5.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_5);
		
		lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_6);
		
		lblNewLabel_7 = new JLabel("Obsequio:");
		lblNewLabel_7.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_7);
		
		txtObsequio1 = new JTextField();
		txtObsequio1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		txtObsequio1.setColumns(10);
		panel_4.add(txtObsequio1);
		
		lblNewLabel_8 = new JLabel("Desde S/.200 a menores de S/.400");
		lblNewLabel_8.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_8);
		
		lblNewLabel_9 = new JLabel("");
		lblNewLabel_9.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_9);
		
		lblNewLabel_10 = new JLabel("Obsequio:");
		lblNewLabel_10.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_10);
		
		txtObsequio2 = new JTextField();
		txtObsequio2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		txtObsequio2.setColumns(10);
		panel_4.add(txtObsequio2);
		
		lblNewLabel_11 = new JLabel("Desde S/.400 en adelante");
		lblNewLabel_11.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_11);
		
		lblNewLabel_12 = new JLabel("");
		lblNewLabel_12.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_12);
		
		lblNewLabel_13 = new JLabel("Obsequio:");
		lblNewLabel_13.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_4.add(lblNewLabel_13);
		
		txtObsequio3 = new JTextField();
		txtObsequio3.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		txtObsequio3.setColumns(10);
		panel_4.add(txtObsequio3);
		
		
		Obsequio.cargarObsequios();
		txtObsequio0.setText(String.valueOf(Obsequio.obsequio0));
		txtObsequio1.setText(String.valueOf(Obsequio.obsequio1));
		txtObsequio2.setText(String.valueOf(Obsequio.obsequio2));
		txtObsequio3.setText(String.valueOf(Obsequio.obsequio3));
		
	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnRestaurar) {
			actionPerformedBtnRestaurar(e);
		}
		if (e.getSource() == btnAceptar) {
			actionPerformedBtnAceptar(e);
		}
	}
	protected void actionPerformedBtnAceptar(ActionEvent e) {
		try {
			
			// Obtener los valores ingresados por el usuario desde los campos de texto y asignarlos a las variables de la clase Obsequio
			Obsequio.obsequio0 = txtObsequio0.getText();
			Obsequio.obsequio1 = txtObsequio1.getText();
			Obsequio.obsequio2 = txtObsequio2.getText();
			Obsequio.obsequio3 = txtObsequio3.getText();
			
	        // Mostrar los descuentos en consola      Solo para verificar
	        System.out.println("Obsequio 0: " + Obsequio.obsequio0);
	        System.out.println("Obsequio 1: " + Obsequio.obsequio1);
	        System.out.println("Obsequio 2: " + Obsequio.obsequio2);
	        System.out.println("Obsequio 3: " + Obsequio.obsequio3);
	        
	        // Guardar los descuentos actualizados en el archivo
	        Obsequio.guardarObsequios();

	        // Mostrar mensaje de confirmaci�n
	        JOptionPane.showMessageDialog(null, "Cambios Aplicados", "Información", JOptionPane.INFORMATION_MESSAGE);
	        
	        
	    } catch (NumberFormatException ex) {
	    	// En caso de que el formato no sea v�lido
	        JOptionPane.showMessageDialog(null, "Por favor, ingresa valores numéricos válidos.", "Error", JOptionPane.ERROR_MESSAGE);
	        
	    }
		// Mostrar los descuentos actualizados en un cuadro de di�logo
		JOptionPane.showMessageDialog(null, "Obsequio 0: " + Obsequio.obsequio0 + "\n" +
                "Obsequio 1: " + Obsequio.obsequio1 + "\n" +
                "Obsequio 2: " + Obsequio.obsequio2 + "\n" +
                "Obsequio 3: " + Obsequio.obsequio3, 
                "Obsequio Actualizados", JOptionPane.INFORMATION_MESSAGE);
	}
	
	
	protected void actionPerformedBtnRestaurar(ActionEvent e) {
		Obsequio.restaurarValoresPorDefecto();
		Obsequio.cargarObsequios();
        txtObsequio0.setText(String.valueOf(Obsequio.obsequio0));
        txtObsequio1.setText(String.valueOf(Obsequio.obsequio1));
        txtObsequio2.setText(String.valueOf(Obsequio.obsequio2));
        txtObsequio3.setText(String.valueOf(Obsequio.obsequio3));
        
        JOptionPane.showMessageDialog(null, "Cambios cancelados. Se han restaurado los valores guardados.", "Cancelar", JOptionPane.INFORMATION_MESSAGE);
		
	}
}
