package GUI;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;

public class PnlBienvenida extends JPanel {
	private JLabel lblNewLabel;

	/**
	 * Create the panel.
	 */
	public PnlBienvenida() {
		setBackground(new Color(255, 255, 255));
		setLayout(null);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 55));
		lblNewLabel.setBounds(168, 186, 686, 232);
		add(lblNewLabel);

	}
}
