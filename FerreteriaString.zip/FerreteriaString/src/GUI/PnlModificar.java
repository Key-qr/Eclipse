package GUI;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PnlModificar extends JPanel implements ActionListener {
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JPanel panel_3;
	private JPanel panel_4;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JPanel panel_5;
	private JPanel panel_6;
	private JLabel lblNewLabel_2;
	private JComboBox cmbCodigos;
	private JButton btnModificarProducto;
	private JLabel lblNewLabel_3;
	private JTextField txtPrecio;
	private JLabel lblNewLabel_4;
	private JTextField txtCantidad;

	/**
	 * Create the panel.
	 */
	public PnlModificar() {
		setBackground(new Color(255, 255, 255));
		setLayout(new BorderLayout(0, 0));
		
		panel = new JPanel();
		add(panel, BorderLayout.NORTH);
		
		lblNewLabel = new JLabel("MODIFICAR PRODUCTOS");
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 55));
		panel.add(lblNewLabel);
		
		panel_1 = new JPanel();
		panel_1.setBorder(new EmptyBorder(0, 30, 70, 30));
		add(panel_1, BorderLayout.SOUTH);
		panel_1.setLayout(new GridLayout(0, 1, 0, 0));
		
		btnModificarProducto = new JButton("MOIFICAR PRODUCTO");
		btnModificarProducto.addActionListener(this);
		btnModificarProducto.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 16));
		panel_1.add(btnModificarProducto);
		
		panel_2 = new JPanel();
		add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		panel_3 = new JPanel();
		panel_2.add(panel_3, BorderLayout.NORTH);
		
		lblNewLabel_1 = new JLabel("AQU\u00CD PODR\u00C1S MODIFICAR LAS CANTIDADES Y LOS PRECIOS DE UN PRODUCTO");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_3.add(lblNewLabel_1);
		
		panel_4 = new JPanel();
		panel_2.add(panel_4, BorderLayout.CENTER);
		panel_4.setLayout(new BorderLayout(0, 0));
		
		panel_5 = new JPanel();
		panel_5.setBorder(new EmptyBorder(0, 30, 0, 30));
		panel_4.add(panel_5, BorderLayout.NORTH);
		panel_5.setLayout(new GridLayout(0, 4, 0, 0));
		
		lblNewLabel_2 = new JLabel("PRODUCTO:");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_5.add(lblNewLabel_2);
		
		cmbCodigos = new JComboBox();
		cmbCodigos.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		panel_5.add(cmbCodigos);
		
		panel_6 = new JPanel();
		panel_6.setBorder(new EmptyBorder(150, 50, 150, 50));
		panel_4.add(panel_6, BorderLayout.CENTER);
		panel_6.setLayout(new GridLayout(0, 2, 0, 0));
		
		lblNewLabel_3 = new JLabel("Precio:");
		lblNewLabel_3.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_6.add(lblNewLabel_3);
		
		txtPrecio = new JTextField();
		txtPrecio.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_6.add(txtPrecio);
		txtPrecio.setColumns(10);
		
		lblNewLabel_4 = new JLabel("Cantidad");
		lblNewLabel_4.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_6.add(lblNewLabel_4);
		
		txtCantidad = new JTextField();
		txtCantidad.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_6.add(txtCantidad);
		txtCantidad.setColumns(10);
		
		//Array de opciones para el combobox
		String [] opciones = cargarOpciones();
		for (String opcion : opciones) {
			cmbCodigos.addItem(opcion);
		}

	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnModificarProducto) {
			actionPerformedBtnModificarProducto(e);
		}
	}
	protected void actionPerformedBtnModificarProducto(ActionEvent e) {
		Properties props = new Properties();
		String valor;
		String codigoPintura = (String) cmbCodigos.getSelectedItem();
		String nuevoPrecio = txtPrecio.getText();
		String nuevaCantidad = txtCantidad.getText();
		
		try {
			//Cargar archivo properties
            FileInputStream input = new FileInputStream("src/Recursos/pinturas.properties");
            props.load(input);
            input.close();
			
            //Verificar si existe la clave
            if (props.containsKey(codigoPintura)) { //�props contiene la llave "codigoPintura"?
            	//Obtenemos el valor de la clave "codigoPintura"
            	valor = props.getProperty(codigoPintura);
            	String partes[] = valor.split(","); //Separamos en un array
            	partes[8]= nuevoPrecio;
            	partes[10] = nuevaCantidad;
            	//cambiamos el valor
            	valor = String.join(",",partes);
            	//modificamos el valor de la clave
            	 props.setProperty(codigoPintura, valor);
            	
            //Guardamos los cambios
            FileOutputStream output = new FileOutputStream("src/Recursos/pinturas.properties");
            props.store(output, null);
            output.close();
            System.out.println("Clave actualizada correctamente.");
            }
				
			
		}catch(IOException f){
			System.out.println("Error al guardar las pinturas.");
		}
	}
	
	public static String[] cargarOpciones() {
		Properties props = new Properties();
		String [] opciones = new String[80];
		int i=0;
		try {
			FileInputStream input = new FileInputStream("src/recursos/pinturas.properties");
			props.load(input);
			for(String clave :  props.stringPropertyNames()) {
				opciones[i] = clave;
				i = i+1;
			}
		}catch(IOException f){
			System.out.println("Error al guardar las pinturas.");
		}
		return opciones;
	}
	
}
