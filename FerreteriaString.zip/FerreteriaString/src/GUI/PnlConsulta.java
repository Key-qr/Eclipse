package GUI;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.awt.event.ActionEvent;

public class PnlConsulta extends JPanel implements ActionListener {
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JPanel panel_3;
	private JPanel panel_4;
	private JPanel panel_5;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JTextField txtPrecio;
	private JLabel lblNewLabel_4;
	private JTextField txtPresentacion;
	private JLabel lblNewLabel_5;
	private JTextField txtMarca;
	private JLabel lblNewLabel_6;
	private JTextField txtLavabilidad;
	private JLabel lblNewLabel_7;
	private JTextField txtColor;
	private JLabel lblNewLabel_8;
	private JTextField txtTiempoRepintado;
	private JLabel lblNewLabel_9;
	private JTextField txtTipo;
	private JLabel lblNewLabel_10;
	private JTextField txtRendimiento;
	private JLabel lblNewLabel_11;
	private JTextField txtAcabado;
	private JLabel lblNewLabel_12;
	private JTextField txtTiempoVida;
	private JLabel lblNewLabel_13;
	private JButton btnConsultar;
	private JComboBox cmbCodigos;

	/**
	 * Create the panel.
	 */
	public PnlConsulta() {
		setBackground(new Color(255, 255, 255));
		setLayout(new BorderLayout(0, 0));
		
		panel = new JPanel();
		add(panel, BorderLayout.NORTH);
		panel.setLayout(new GridLayout(2, 1, 0, 0));
		
		panel_4 = new JPanel();
		panel.add(panel_4);
		
		lblNewLabel = new JLabel("M\u00D3DULO DE CONSULTAS");
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 55));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		panel_4.add(lblNewLabel);
		
		panel_5 = new JPanel();
		panel.add(panel_5);
		
		lblNewLabel_1 = new JLabel("AQU\u00CD PODR\u00C1S CONSULTAR PRODUCTOS DE LA TIENDA");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_5.add(lblNewLabel_1);
		
		panel_1 = new JPanel();
		add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		panel_2 = new JPanel();
		panel_2.setBorder(new EmptyBorder(0, 30, 0, 30));
		panel_1.add(panel_2, BorderLayout.NORTH);
		panel_2.setLayout(new GridLayout(0, 4, 0, 0));
		
		lblNewLabel_2 = new JLabel("PRODUCTO    ");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		panel_2.add(lblNewLabel_2);
		
		cmbCodigos = new JComboBox();
		panel_2.add(cmbCodigos);
		
		lblNewLabel_13 = new JLabel("");
		lblNewLabel_13.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_2.add(lblNewLabel_13);
		
		btnConsultar = new JButton("CONSULTAR");
		btnConsultar.addActionListener(this);
		btnConsultar.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_2.add(btnConsultar);
		
		panel_3 = new JPanel();
		panel_3.setBorder(new EmptyBorder(40, 40, 80, 40));
		panel_1.add(panel_3, BorderLayout.CENTER);
		panel_3.setLayout(new GridLayout(5, 4, 0, 0));
		
		lblNewLabel_3 = new JLabel("Precio:");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_3.add(lblNewLabel_3);
		
		txtPrecio = new JTextField();
		txtPrecio.setEnabled(false);
		txtPrecio.setEditable(false);
		txtPrecio.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
		panel_3.add(txtPrecio);
		txtPrecio.setColumns(10);
		
		lblNewLabel_4 = new JLabel("Presentaci\u00F3n:");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_3.add(lblNewLabel_4);
		
		txtPresentacion = new JTextField();
		txtPresentacion.setEnabled(false);
		txtPresentacion.setEditable(false);
		txtPresentacion.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
		txtPresentacion.setColumns(10);
		panel_3.add(txtPresentacion);
		
		lblNewLabel_5 = new JLabel("Marca:");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_3.add(lblNewLabel_5);
		
		txtMarca = new JTextField();
		txtMarca.setEnabled(false);
		txtMarca.setEditable(false);
		txtMarca.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
		txtMarca.setColumns(10);
		panel_3.add(txtMarca);
		
		lblNewLabel_6 = new JLabel("Lavabilidad:");
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_3.add(lblNewLabel_6);
		
		txtLavabilidad = new JTextField();
		txtLavabilidad.setEnabled(false);
		txtLavabilidad.setEditable(false);
		txtLavabilidad.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
		txtLavabilidad.setColumns(10);
		panel_3.add(txtLavabilidad);
		
		lblNewLabel_7 = new JLabel("Color:");
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_3.add(lblNewLabel_7);
		
		txtColor = new JTextField();
		txtColor.setEnabled(false);
		txtColor.setEditable(false);
		txtColor.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
		txtColor.setColumns(10);
		panel_3.add(txtColor);
		
		lblNewLabel_8 = new JLabel("Tiempo de repintado:");
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_3.add(lblNewLabel_8);
		
		txtTiempoRepintado = new JTextField();
		txtTiempoRepintado.setEnabled(false);
		txtTiempoRepintado.setEditable(false);
		txtTiempoRepintado.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
		txtTiempoRepintado.setColumns(10);
		panel_3.add(txtTiempoRepintado);
		
		lblNewLabel_9 = new JLabel("Tipo:");
		lblNewLabel_9.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_9.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_3.add(lblNewLabel_9);
		
		txtTipo = new JTextField();
		txtTipo.setEnabled(false);
		txtTipo.setEditable(false);
		txtTipo.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
		txtTipo.setColumns(10);
		panel_3.add(txtTipo);
		
		lblNewLabel_10 = new JLabel("Rendimiento");
		lblNewLabel_10.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_10.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_3.add(lblNewLabel_10);
		
		txtRendimiento = new JTextField();
		txtRendimiento.setEnabled(false);
		txtRendimiento.setEditable(false);
		txtRendimiento.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
		txtRendimiento.setColumns(10);
		panel_3.add(txtRendimiento);
		
		lblNewLabel_11 = new JLabel("Acabado:");
		lblNewLabel_11.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_11.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_3.add(lblNewLabel_11);
		
		txtAcabado = new JTextField();
		txtAcabado.setEnabled(false);
		txtAcabado.setEditable(false);
		txtAcabado.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
		txtAcabado.setColumns(10);
		panel_3.add(txtAcabado);
		
		lblNewLabel_12 = new JLabel("Tiempo de vida");
		lblNewLabel_12.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_12.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		panel_3.add(lblNewLabel_12);
		
		txtTiempoVida = new JTextField();
		txtTiempoVida.setEnabled(false);
		txtTiempoVida.setEditable(false);
		txtTiempoVida.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
		txtTiempoVida.setColumns(10);
		panel_3.add(txtTiempoVida);
		
		//Array de opciones para el combobox
		String [] opciones = cargarOpciones();
		for (String opcion : opciones) {
		    cmbCodigos.addItem(opcion);
		}
	}


	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnConsultar) {
			actionPerformedBtnConsultar(e);
		}
	}
	protected void actionPerformedBtnConsultar(ActionEvent e) {
		Properties props = new Properties();
		String valor;
		String codigoPintura = (String) cmbCodigos.getSelectedItem();
		try {
			FileInputStream input = new FileInputStream("src/recursos/pinturas.properties");
			props.load(input);
			for(String clave :  props.stringPropertyNames()) {
				if (clave.equals(codigoPintura)) {
					valor = props.getProperty(clave);
					String partes[] = valor.split(",");
					txtMarca.setText(partes[0]);
					txtColor.setText(partes[1]);
					txtTipo.setText(partes[2]);
					txtAcabado.setText(partes[3]);
					txtPresentacion.setText(partes[4]);
					txtLavabilidad.setText(partes[5]);
					txtRendimiento.setText(partes[6]);
					txtTiempoRepintado.setText(partes[7]);
					txtPrecio.setText("S/. "+partes[8]);
					txtTiempoVida.setText(partes[9]);
				}
				
				
			}
		}catch(IOException f){
			System.out.println("Error al guardar las pinturas.");
		}
	}
	
	public static String[] cargarOpciones() {
		Properties props = new Properties();
		String [] opciones = new String[80];
		int i=0;
		try {
			FileInputStream input = new FileInputStream("src/recursos/pinturas.properties");
			props.load(input);
			for(String clave :  props.stringPropertyNames()) {
				opciones[i] = clave;
				i = i+1;
			}
		}catch(IOException f){
			System.out.println("Error al guardar las pinturas.");
		}
		return opciones;
	}
}