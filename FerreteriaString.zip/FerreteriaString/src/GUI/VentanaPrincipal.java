
package GUI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.CardLayout;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.Box;
import javax.swing.BoxLayout;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import Logica.Pintura;
import javax.swing.JLabel;
public class VentanaPrincipal extends JFrame implements ActionListener {
	
	PnlBienvenida bienvenida = new PnlBienvenida();
	PnlVentas ventas = new PnlVentas();
	PnlDescuentos descuentos = new PnlDescuentos();
	PnlObsequios obsequios = new PnlObsequios();
	PnlConsulta consulta = new PnlConsulta();
	PnlModificar modificar = new PnlModificar();
	PnlStock stock = new PnlStock();
	PnlAcercaDe acercaDe = new PnlAcercaDe();
	PnlContacto contacto = new PnlContacto();
	//Dinamismo
	CardLayout vista;

	private JPanel contentPane;
	private JPanel pnlMenu;
	private JPanel pnlPrincipal;
	private JButton btnVentas;
	private JButton btnDescuento;
	private JButton btnObsequio;
	private JButton btnConsulta;
	private JButton btnModificar;
	private JButton btnStock;
	private JButton btnAcercaDe;
	public ArrayList<Pintura> pinturas = new ArrayList<>();
	private JButton btnContacto;
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal frame = new VentanaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal() {
		setResizable(false);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1062, 697);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		pnlMenu = new JPanel();
		pnlMenu.setBackground(new Color(125, 51, 208));
		pnlMenu.setBounds(0, 0, 118, 658);
		contentPane.add(pnlMenu);
		pnlMenu.setLayout(new BoxLayout(pnlMenu, BoxLayout.Y_AXIS));
		pnlMenu.add(Box.createVerticalStrut(40));
		
		btnVentas = new JButton("Vender");
		btnVentas.addActionListener(this);
		btnVentas.setFocusPainted(false);
		btnVentas.setMinimumSize(new Dimension(118, 62));
		btnVentas.setMaximumSize(new Dimension(118, 62));
		btnVentas.setBorderPainted(false);
		btnVentas.setHorizontalTextPosition(SwingConstants.CENTER);
		btnVentas.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnVentas.setVerticalAlignment(SwingConstants.TOP);
		btnVentas.setFont(new Font("Arial", Font.BOLD, 14));
		btnVentas.setForeground(new Color(255, 255, 255));
		btnVentas.setBackground(new Color(125, 51, 208));
		btnVentas.setOpaque(true);
		btnVentas.setContentAreaFilled(true);
		btnVentas.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/Imagenes/carro 32-32.png")));
		pnlMenu.add(btnVentas);
		
		btnConsulta = new JButton("Consultar");
		btnConsulta.addActionListener(this);
		btnConsulta.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/Imagenes/base-de-datos32-32.png")));
		btnConsulta.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnConsulta.setVerticalAlignment(SwingConstants.TOP);
		btnConsulta.setOpaque(true);
		btnConsulta.setMinimumSize(new Dimension(118, 62));
		btnConsulta.setMaximumSize(new Dimension(118, 62));
		btnConsulta.setHorizontalTextPosition(SwingConstants.CENTER);
		btnConsulta.setForeground(Color.WHITE);
		btnConsulta.setFont(new Font("Arial", Font.BOLD, 14));
		btnConsulta.setFocusPainted(false);
		btnConsulta.setContentAreaFilled(true);
		btnConsulta.setBorderPainted(false);
		btnConsulta.setBackground(new Color(125, 51, 208));
		pnlMenu.add(btnConsulta);
		
		btnStock = new JButton("Stock");
		btnStock.addActionListener(this);
		btnStock.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/Imagenes/almacen32-32.png")));
		btnStock.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnStock.setVerticalAlignment(SwingConstants.TOP);
		btnStock.setOpaque(true);
		btnStock.setMinimumSize(new Dimension(118, 62));
		btnStock.setMaximumSize(new Dimension(118, 62));
		btnStock.setHorizontalTextPosition(SwingConstants.CENTER);
		btnStock.setForeground(Color.WHITE);
		btnStock.setFont(new Font("Arial", Font.BOLD, 14));
		btnStock.setFocusPainted(false);
		btnStock.setContentAreaFilled(true);
		btnStock.setBorderPainted(false);
		btnStock.setBackground(new Color(125, 51, 208));
		pnlMenu.add(btnStock);
		
		btnAcercaDe = new JButton("<html><center>Acerca de<br>la tienda</center></html>");
		btnAcercaDe.setFocusPainted(false);
		btnAcercaDe.setPreferredSize(new Dimension(150, 100));
		btnAcercaDe.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/Imagenes/acerca-de32-32.png")));
		btnAcercaDe.addActionListener(this);
		
		btnModificar = new JButton("Modificar");
		btnModificar.addActionListener(this);
		
		btnDescuento = new JButton("Descuentos");
		btnDescuento.addActionListener(this);
		btnDescuento.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/Imagenes/descuento32-32.png")));
		btnDescuento.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnDescuento.setVerticalAlignment(SwingConstants.TOP);
		btnDescuento.setOpaque(true);
		btnDescuento.setMinimumSize(new Dimension(118, 62));
		btnDescuento.setMaximumSize(new Dimension(118, 62));
		btnDescuento.setHorizontalTextPosition(SwingConstants.CENTER);
		btnDescuento.setForeground(Color.WHITE);
		btnDescuento.setFont(new Font("Arial", Font.BOLD, 14));
		btnDescuento.setFocusPainted(false);
		btnDescuento.setContentAreaFilled(true);
		btnDescuento.setBorderPainted(false);
		btnDescuento.setBackground(new Color(125, 51, 208));
		pnlMenu.add(btnDescuento);
		
		btnObsequio = new JButton("Obsequios");
		btnObsequio.addActionListener(this);
		btnObsequio.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/Imagenes/regalo32-32.png")));
		btnObsequio.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnObsequio.setVerticalAlignment(SwingConstants.TOP);
		btnObsequio.setOpaque(true);
		btnObsequio.setMinimumSize(new Dimension(118, 62));
		btnObsequio.setMaximumSize(new Dimension(118, 62));
		btnObsequio.setHorizontalTextPosition(SwingConstants.CENTER);
		btnObsequio.setForeground(Color.WHITE);
		btnObsequio.setFont(new Font("Arial", Font.BOLD, 14));
		btnObsequio.setFocusPainted(false);
		btnObsequio.setContentAreaFilled(true);
		btnObsequio.setBorderPainted(false);
		btnObsequio.setBackground(new Color(125, 51, 208));
		pnlMenu.add(btnObsequio);
		btnModificar.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/Imagenes/editar32-32.png")));
		btnModificar.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnModificar.setVerticalAlignment(SwingConstants.TOP);
		btnModificar.setOpaque(true);
		btnModificar.setMinimumSize(new Dimension(118, 62));
		btnModificar.setMaximumSize(new Dimension(118, 62));
		btnModificar.setHorizontalTextPosition(SwingConstants.CENTER);
		btnModificar.setForeground(Color.WHITE);
		btnModificar.setFont(new Font("Arial", Font.BOLD, 14));
		btnModificar.setFocusPainted(false);
		btnModificar.setContentAreaFilled(true);
		btnModificar.setBorderPainted(false);
		btnModificar.setBackground(new Color(125, 51, 208));
		pnlMenu.add(btnModificar);
		
		btnContacto = new JButton("Contacto");
		btnContacto.addActionListener(this);
		btnContacto.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/Imagenes/contacto32x32.png")));
		btnContacto.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnContacto.setVerticalAlignment(SwingConstants.TOP);
		btnContacto.setOpaque(true);
		btnContacto.setMinimumSize(new Dimension(118, 62));
		btnContacto.setMaximumSize(new Dimension(118, 62));
		btnContacto.setHorizontalTextPosition(SwingConstants.CENTER);
		btnContacto.setForeground(Color.WHITE);
		btnContacto.setFont(new Font("Arial", Font.BOLD, 14));
		btnContacto.setFocusPainted(false);
		btnContacto.setContentAreaFilled(true);
		btnContacto.setBorderPainted(false);
		btnContacto.setBackground(new Color(125, 51, 208));
		pnlMenu.add(btnContacto);
		
		btnAcercaDe.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnAcercaDe.setVerticalAlignment(SwingConstants.TOP);
		btnAcercaDe.setOpaque(true);
		btnAcercaDe.setMinimumSize(new Dimension(Integer.MAX_VALUE, 62));
		btnAcercaDe.setMaximumSize(new Dimension(150, 80));
		btnAcercaDe.setHorizontalTextPosition(SwingConstants.CENTER);
		btnAcercaDe.setForeground(Color.WHITE);
		btnAcercaDe.setFont(new Font("Arial", Font.BOLD, 14));
		btnAcercaDe.setContentAreaFilled(true);
		btnAcercaDe.setBorderPainted(false);
		btnAcercaDe.setBackground(new Color(125, 51, 208));
		pnlMenu.add(btnAcercaDe);
		
		pnlPrincipal = new JPanel();
		pnlPrincipal.setBackground(new Color(255, 255, 255));
		pnlPrincipal.setForeground(new Color(255, 255, 255));
		pnlPrincipal.setBounds(119, 0, 927, 658);
		contentPane.add(pnlPrincipal);
		pnlPrincipal.setLayout(new CardLayout(0, 0));
		
		//Lo m�s picante
		vista = (CardLayout) pnlPrincipal.getLayout();
		//Las llamadas a los p�neles
		pnlPrincipal.add(bienvenida,"Bienvenida");
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/Imagenes/Bienvenida 927x654.png")));
		lblNewLabel.setBounds(0, 0, 927, 658);
		bienvenida.add(lblNewLabel);
		pnlPrincipal.add(ventas,"Ventas");
		pnlPrincipal.add(descuentos,"Descuentos");
		pnlPrincipal.add(obsequios,"Obsequios");
		pnlPrincipal.add(consulta,"Consulta");
		pnlPrincipal.add(modificar, "Modificar");
		pnlPrincipal.add(stock,"Stock");
		pnlPrincipal.add(acercaDe,"AcercaDe");
		pnlPrincipal.add(contacto,"Contacto");
		
		Pintura.guardarPinturas();
		
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnContacto) {
			actionPerformedBtnContacto(e);
		}
		if (e.getSource() == btnStock) {
			actionPerformedBtnStock(e);
		}
		if (e.getSource() == btnModificar) {
			actionPerformedBtnModificar(e);
		}
		if (e.getSource() == btnConsulta) {
			actionPerformedBtnConsulta(e);
		}
		if (e.getSource() == btnObsequio) {
			actionPerformedBtnObsequio(e);
		}
		if (e.getSource() == btnDescuento) {
			actionPerformedBtnDescuento(e);
		}
		if (e.getSource() == btnVentas) {
			actionPerformedBtnVentas(e);
		}
		if (e.getSource() == btnAcercaDe) {
			actionPerformedBtnAcercaDe(e);
		}
	}
	protected void actionPerformedBtnVentas(ActionEvent e) {
		btnVentas.setBackground(new Color(0, 0, 0)); //color negro
		btnDescuento.setBackground(new Color(125, 51, 208));  //color morado
		btnObsequio.setBackground(new Color(125, 51, 208));
		btnConsulta.setBackground(new Color(125, 51, 208));
		btnModificar.setBackground(new Color(125, 51, 208));
		btnStock.setBackground(new Color(125, 51, 208));
		btnAcercaDe.setBackground(new Color(125, 51, 208));
		btnContacto.setBackground(new Color(125, 51, 208));
		
		vista.show(pnlPrincipal, "Ventas");
		//SwingUtilities.updateComponentTreeUI(this);
		//this.repaint();
	}
	protected void actionPerformedBtnDescuento(ActionEvent e) {
		btnVentas.setBackground(new Color(125, 51, 208));
		btnDescuento.setBackground(new Color(0, 0, 0)); //negro
		btnObsequio.setBackground(new Color(125, 51, 208));
		btnConsulta.setBackground(new Color(125, 51, 208));
		btnModificar.setBackground(new Color(125, 51, 208));
		btnStock.setBackground(new Color(125, 51, 208));
		btnAcercaDe.setBackground(new Color(125, 51, 208));
		btnContacto.setBackground(new Color(125, 51, 208));
		
		vista.show(pnlPrincipal, "Descuentos");
	}
	protected void actionPerformedBtnObsequio(ActionEvent e) {
		btnVentas.setBackground(new Color(125, 51, 208));
		btnDescuento.setBackground(new Color(125, 51, 208));
		btnObsequio.setBackground(new Color(0, 0, 0));
		btnConsulta.setBackground(new Color(125, 51, 208));
		btnModificar.setBackground(new Color(125, 51, 208));
		btnStock.setBackground(new Color(125, 51, 208));
		btnAcercaDe.setBackground(new Color(125, 51, 208));
		btnContacto.setBackground(new Color(125, 51, 208));
		
		vista.show(pnlPrincipal, "Obsequios");
	}
	
	protected void actionPerformedBtnConsulta(ActionEvent e) {
		btnVentas.setBackground(new Color(125, 51, 208));
		btnDescuento.setBackground(new Color(125, 51, 208));
		btnObsequio.setBackground(new Color(125, 51, 208));
		btnConsulta.setBackground(new Color(0, 0, 0));
		btnModificar.setBackground(new Color(125, 51, 208));
		btnStock.setBackground(new Color(125, 51, 208));
		btnAcercaDe.setBackground(new Color(125, 51, 208));
		btnContacto.setBackground(new Color(125, 51, 208));
		
		vista.show(pnlPrincipal, "Consulta");
	}
	
	protected void actionPerformedBtnModificar(ActionEvent e) {
		btnVentas.setBackground(new Color(125, 51, 208));
		btnDescuento.setBackground(new Color(125, 51, 208));
		btnObsequio.setBackground(new Color(125, 51, 208));
		btnConsulta.setBackground(new Color(125, 51, 208));
		btnModificar.setBackground(new Color(0, 0, 0));
		btnStock.setBackground(new Color(125, 51, 208));
		btnAcercaDe.setBackground(new Color(125, 51, 208));
		btnContacto.setBackground(new Color(125, 51, 208));
		
		vista.show(pnlPrincipal, "Modificar");
	}
	
	protected void actionPerformedBtnStock(ActionEvent e) {
		btnVentas.setBackground(new Color(125, 51, 208));
		btnDescuento.setBackground(new Color(125, 51, 208));
		btnObsequio.setBackground(new Color(125, 51, 208));
		btnConsulta.setBackground(new Color(125, 51, 208));
		btnModificar.setBackground(new Color(125, 51, 208));
		btnStock.setBackground(new Color(0, 0, 0));
		btnAcercaDe.setBackground(new Color(125, 51, 208));
		btnContacto.setBackground(new Color(125, 51, 208));
		
		vista.show(pnlPrincipal, "Stock");
	}
	
	protected void actionPerformedBtnAcercaDe(ActionEvent e) {
		btnVentas.setBackground(new Color(125, 51, 208));
		btnDescuento.setBackground(new Color(125, 51, 208));
		btnObsequio.setBackground(new Color(125, 51, 208));
		btnConsulta.setBackground(new Color(125, 51, 208));
		btnModificar.setBackground(new Color(125, 51, 208));
		btnStock.setBackground(new Color(125, 51, 208));
		btnAcercaDe.setBackground(new Color(0, 0, 0));
		btnContacto.setBackground(new Color(125, 51, 208));
		
		vista.show(pnlPrincipal, "AcercaDe");
	}

	protected void actionPerformedBtnContacto(ActionEvent e) {
		btnVentas.setBackground(new Color(125, 51, 208));
		btnDescuento.setBackground(new Color(125, 51, 208));
		btnObsequio.setBackground(new Color(125, 51, 208));
		btnConsulta.setBackground(new Color(125, 51, 208));
		btnModificar.setBackground(new Color(125, 51, 208));
		btnStock.setBackground(new Color(125, 51, 208));
		btnAcercaDe.setBackground(new Color(125, 51, 208));
		btnContacto.setBackground(new Color(0, 0, 0));
		
		vista.show(pnlPrincipal, "Contacto");
		
	}
}