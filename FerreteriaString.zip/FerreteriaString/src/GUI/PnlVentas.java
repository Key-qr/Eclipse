package GUI;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.border.EmptyBorder;
import java.awt.ScrollPane;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.awt.event.ActionEvent;

public class PnlVentas extends JPanel implements ActionListener {
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JPanel panel_3;
	private JPanel panel_4;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JTextField txtCantidad;
	private JLabel lblNewLabel_3;
	private JButton btnAgregarProducto;
	private JButton btnProcesarVenta;
	private JTable table;
	private JScrollPane scrollPaneResumen;
	private JComboBox cmbCodigos;
	private DefaultTableModel tabla;

	/**
	 * Create the panel.
	 */
	public PnlVentas() {
		setBackground(new Color(255, 255, 255));
		setLayout(new BorderLayout(0, 0));
		
		panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBorder(new EmptyBorder(0, 0, 80, 0));
		add(panel, BorderLayout.NORTH);
		
		lblNewLabel = new JLabel("M\u00D3DULO DE VENTAS");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 55));
		panel.add(lblNewLabel);
		
		panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBorder(new EmptyBorder(40, 60, 50, 60));
		add(panel_1, BorderLayout.SOUTH);
		panel_1.setLayout(new GridLayout(0, 1, 0, 0));
		
		btnProcesarVenta = new JButton("PROCESAR VENTA");
		btnProcesarVenta.addActionListener(this);
		btnProcesarVenta.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 16));
		panel_1.add(btnProcesarVenta);
		
		panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBorder(new EmptyBorder(0, 40, 0, 40));
		add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255));
		panel_2.add(panel_3, BorderLayout.NORTH);
		panel_3.setLayout(new GridLayout(0, 6, 0, 0));
		
		lblNewLabel_1 = new JLabel("PRODUCTO:   ");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_3.add(lblNewLabel_1);
		
		cmbCodigos = new JComboBox();
		panel_3.add(cmbCodigos);
		
		lblNewLabel_2 = new JLabel("CANTIDAD:    ");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_3.add(lblNewLabel_2);
		
		txtCantidad = new JTextField();
		txtCantidad.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		txtCantidad.setColumns(10);
		panel_3.add(txtCantidad);
		
		lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_3.add(lblNewLabel_3);
		
		btnAgregarProducto = new JButton("AGREGAR");
		btnAgregarProducto.addActionListener(this);
		btnAgregarProducto.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_3.add(btnAgregarProducto);
		
		panel_4 = new JPanel();
		panel_4.setBackground(new Color(255, 255, 255));
		panel_4.setBorder(new EmptyBorder(40, 0, 0, 0));
		panel_2.add(panel_4, BorderLayout.CENTER);
				
		
		//Creamos los t�tulos
		String titulos[] = {"CÓDIGO","MARCA","COLOR","PRESENTACIÓN","PRECIO UNITARIO","CANTIDAD","TOTAL"};
		//Usamos un DefaultTableModel para agregar filas de forma m�s f�cil
		tabla = new DefaultTableModel(null,titulos) {
			public boolean isCellEditable(int row, int column) {
		        // Para que no se edite ninguna columna
		        return false;
		    }
		};
		table = new JTable(tabla);
		
		scrollPaneResumen = new JScrollPane(table);
		scrollPaneResumen.setBackground(new Color(255, 255, 255));
		scrollPaneResumen.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		scrollPaneResumen.setPreferredSize(new Dimension(800, 250));
		scrollPaneResumen.setBorder(new EmptyBorder(0, 0, 50, 0));
		scrollPaneResumen.setBounds(53,235,802,277);
		panel_4.add(scrollPaneResumen);
		
		//Array de opciones para el combobox
		String [] opciones = cargarOpciones();
		for (String opcion : opciones) {
			cmbCodigos.addItem(opcion);
		}
		
	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnProcesarVenta) {
			actionPerformedBtnProcesarVenta(e);
		}
		if (e.getSource() == btnAgregarProducto) {
			actionPerformedBtnAgregarProducto(e);
		}
	}
	protected void actionPerformedBtnAgregarProducto(ActionEvent e) {
		ArrayList<String> codigos = new ArrayList<>(); // Captura los códigos del Table
		Properties props = new Properties();
		String valor;
		String codigoPintura = (String) cmbCodigos.getSelectedItem();
		int cantidad = (int) Double.parseDouble(txtCantidad.getText());
		Object valorCodigo;
		
		try {
			FileInputStream input = new FileInputStream("src/recursos/pinturas.properties");
			props.load(input);

			boolean productoExistente = false;

			for (int i = 0; i < tabla.getRowCount(); i++) {
				valorCodigo = tabla.getValueAt(i, 0); // Código
				if (valorCodigo.toString().equals(codigoPintura)) {
					// Producto ya en la tabla: actualizar cantidad
					int cantidadActual = Integer.parseInt(tabla.getValueAt(i, 5).toString());
					int nuevaCantidad = cantidadActual + cantidad;

					if (nuevaCantidad <= 0) {
						// Elimina la fila si la cantidad llega a 0 o menos
						tabla.removeRow(i);
						JOptionPane.showMessageDialog(null, "Producto eliminado de la lista porque la cantidad llegó a 0", "Información", JOptionPane.INFORMATION_MESSAGE);
					} else {
						double precioUnitario = Double.parseDouble(tabla.getValueAt(i, 4).toString());
						double nuevoTotal = precioUnitario * nuevaCantidad;

						tabla.setValueAt(nuevaCantidad, i, 5); // Actualiza cantidad
						tabla.setValueAt(nuevoTotal, i, 6);    // Actualiza total
					}
					productoExistente = true;
					break;
				}
			}

			if (!productoExistente) {
				if (props.containsKey(codigoPintura)) {
					valor = props.getProperty(codigoPintura);
					String partes[] = valor.split(",");

					if (cantidad < Double.parseDouble(partes[10]) && cantidad > 0) {
						double precio = Double.parseDouble(partes[8]);
						Object[] fila = {codigoPintura, partes[0], partes[1], partes[4], precio, cantidad, precio * cantidad};
						tabla.addRow(fila);
					} else {
						JOptionPane.showMessageDialog(null, "No hay suficiente cantidad o ingresaste una cantidad negativa o cero", "Información", JOptionPane.INFORMATION_MESSAGE);
					}
				}
			}
		} catch (IOException f) {
			System.out.println("Error al guardar las pinturas.");
		}

		// Limpia el campo cantidad
		txtCantidad.setText("");
	}

	
	
	public static String[] cargarOpciones() {
		Properties props = new Properties();
		String [] opciones = new String[80];
		int i=0;
		try {
			FileInputStream input = new FileInputStream("src/recursos/pinturas.properties");
			props.load(input);
			for(String clave :  props.stringPropertyNames()) {
				opciones[i] = clave;
				i = i+1;
			}
		}catch(IOException f){
			System.out.println("Error al guardar las pinturas.");
		}
		return opciones;
	}
	protected void actionPerformedBtnProcesarVenta(ActionEvent e) {
		ArrayList<String> codigos = new ArrayList<>();
		int cantidadTotal=0;
		double montoTotal=0;
		double montoPagar;
		Object valor;
		String contenido;
		String mensaje = null;
		double descuento;
		String obsequio;
		
		//LLenamos los c�digos
		for (int i = 0; i < tabla.getRowCount(); i++) {
		    valor = tabla.getValueAt(i, 0); // �ndice de la columna deseada
		    codigos.add(valor.toString());
		}
		
		
		Properties props1 = new Properties();
		try {
		    FileInputStream input1 = new FileInputStream("src/Recursos/pinturas.properties");
		    props1.load(input1);
		    input1.close();
		} catch (IOException ex) {
		    System.err.println("Error al cargar pinturas.properties: " + ex.getMessage());
		}
		
		
		if(codigos.size()!=0) {
			// Abrimos el archivo Pinturas.properties
			
			//Calculamos el total de productos comprados
			for (int i = 0; i < tabla.getRowCount(); i++) {
				valor = tabla.getValueAt(i, 5);
				cantidadTotal = cantidadTotal + Integer.parseInt(valor.toString());
				
				//Actualizamos el archivo Pinturas.properties
				contenido = props1.getProperty(codigos.get(i));
				String [] partes = contenido.split(",");
				partes[10] = String.valueOf(Integer.parseInt(partes[10]) - Integer.parseInt(valor.toString()));
				
				contenido = String.join(",",partes);
				//Guardamos
				props1.setProperty(codigos.get(i), contenido);
				try {
					//Guardamos los cambios
					FileOutputStream output1 = new FileOutputStream("src/Recursos/pinturas.properties");
		            props1.store(output1, null);
		            output1.close();
				}catch(IOException f){
					System.out.println("Error al guardar las pinturas.");
				}

			}
			
			//Calculamos el monto total comprado
			for (int i = 0; i < tabla.getRowCount(); i++) {
				valor = tabla.getValueAt(i, 6);
				montoTotal = montoTotal + Double.parseDouble(valor.toString());
			}
			
			//Obtenemos Obsequios.properties
			Properties props2 = new Properties();
			try {
			    FileInputStream input2 = new FileInputStream("src/Recursos/Obsequios.properties");
			    props2.load(input2);
			    input2.close();
			} catch (IOException ex) {
			    System.err.println("Error al cargar Obsequios.properties: " + ex.getMessage());
			}
			//Obtenemos descuentos.properties
			Properties props3 = new Properties();
			try {
			    FileInputStream input3 = new FileInputStream("src/Recursos/descuentos.properties");
			    props3.load(input3);
			    input3.close();
			} catch (IOException ex) {
			    System.err.println("Error al cargar descuentos.properties: " + ex.getMessage());
			}
			
			//Agregamos obsequio y Descuento
			if(montoTotal>=400) {
				obsequio = props2.getProperty("obsequio3");
				descuento = Double.parseDouble(props3.getProperty("porcentaje3"));
			}else {
				if (montoTotal>=200) {
					obsequio = props2.getProperty("obsequio2");
					descuento = Double.parseDouble(props3.getProperty("porcentaje2"));
				}else {
					if (montoTotal>=100) {
						obsequio = props2.getProperty("obsequio1");
						descuento = Double.parseDouble(props3.getProperty("porcentaje1"));
					}else {
						obsequio = props2.getProperty("obsequio0");
						descuento = Double.parseDouble(props3.getProperty("porcentaje0"));
					}
				}
			}
			
			mensaje = "Productos vendidos: \n" + String.join("\n", codigos)+"\n"+
					"Cantidad de productos vendidos: "+cantidadTotal+"\n"+
					"Monto total: "+String.format("%.2f",montoTotal)+"\n"+
					"Obsequio: "+obsequio+"\n"+
					"Dsct(%): "+descuento+"% \n"+
					"Dsct: S/."+String.format("%.2f",montoTotal*descuento/100)+"\n"+
					"Total a pagar: S/."+ String.format("%.2f",montoTotal*(1-descuento/100));
			
			try {
				 Properties props = new Properties();
				 FileInputStream input = new FileInputStream("src/Recursos/Ventas.properties");
	             props.load(input);
	             input.close();
	             
	             //Contaremos cu�nto registros hay
	             int cantidadVentas = 0;
	             for (String clave : props.stringPropertyNames()) {
	                     cantidadVentas++;
	             }
	             
	             //Creamos nueva clave
	             String nuevaClave = "venta" + (cantidadVentas + 1);
	             props.setProperty(nuevaClave, mensaje);
	             
	             //Guardar cambios en el archivo
	             FileOutputStream output = new FileOutputStream("src/Recursos/Ventas.properties");
	             props.store(output, "Registro de Ventas");
	             output.close();
	             
	             String mensajeFinal = "Venta N°"+(cantidadVentas+1)+"\n"+"\n"+mensaje;
	             JOptionPane.showMessageDialog(null, mensajeFinal, "Información de Ventas", JOptionPane.INFORMATION_MESSAGE);
	             
			}catch(IOException ex){
				System.err.println("Error al leer o escribir el archivo: " + ex.getMessage());
			}
			

		}else {
			JOptionPane.showMessageDialog(null, "No hay productos", "Información", JOptionPane.INFORMATION_MESSAGE);
		}
		
		//Borramos el contenido de la cantidad
		txtCantidad.setText("");
		//Volvemos a la primera opci�n del combobox
		cmbCodigos.setSelectedIndex(0);
		//Borramos todos los datos de la tabla
		tabla.setRowCount(0);
		
		
	}
}
