package GUI;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

import Logica.Pintura;

import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.awt.event.ActionEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

public class PnlStock extends JPanel implements ActionListener, MouseListener {
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JLabel lblNewLabel;
	private JButton btnConsultarStock;
	private JTextArea txtMostrarStock;
	private JButton btnLimpiar;

	/**
	 * Create the panel.
	 */
	public PnlStock() {
		setBackground(new Color(255, 255, 255));
		setLayout(new BorderLayout(0, 0));
		
		panel = new JPanel();
		add(panel, BorderLayout.NORTH);
		
		lblNewLabel = new JLabel("STOCK TOTAL DE LA TIENDA");
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 55));
		panel.add(lblNewLabel);
		
		panel_1 = new JPanel();
		panel_1.setBorder(new EmptyBorder(4, 30, 40, 30));
		add(panel_1, BorderLayout.SOUTH);
		panel_1.setLayout(new GridLayout(0, 2, 0, 0));
		
		btnConsultarStock = new JButton("CONSULTAR STOCK");
		btnConsultarStock.addActionListener(this);
		btnConsultarStock.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 16));
		panel_1.add(btnConsultarStock);
		
		btnLimpiar = new JButton("LIMPIAR");
		btnLimpiar.addMouseListener(this);
		btnLimpiar.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 16));
		panel_1.add(btnLimpiar);
		
		panel_2 = new JPanel();
		panel_2.setBorder(new EmptyBorder(50, 30, 50, 30));
		add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new GridLayout(0, 1, 0, 0));
		
		txtMostrarStock = new JTextArea();
		txtMostrarStock.setEditable(false);
		txtMostrarStock.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 16));
		JScrollPane scrollPane = new JScrollPane(txtMostrarStock);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		panel_2.add(scrollPane);
		//panel_2.add(txtMostrarStock);
		

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnConsultarStock) {
			actionPerformedBtnConsultarStock(e);
		}
	}
	protected void actionPerformedBtnConsultarStock(ActionEvent e) {
		txtMostrarStock.setText("");
		Properties props = new Properties();
		String valor;
		int contador=1;
		try {
			FileInputStream input = new FileInputStream("src/recursos/pinturas.properties");
			props.load(input);
			for(String clave :  props.stringPropertyNames()) {
				valor = props.getProperty(clave);
				String partes[] = valor.split(",");
				txtMostrarStock.append("PRODUCTO "+contador+"\n");
				txtMostrarStock.append("Marca: "+partes[0]+"\n");
				txtMostrarStock.append("Color: "+partes[1]+"\n");
				txtMostrarStock.append("Tipo: "+partes[2]+"\n");
				txtMostrarStock.append("Acabado: "+partes[3]+"\n");
				txtMostrarStock.append("Presentación : "+partes[4]+"\n");
				txtMostrarStock.append("Lavabilidad: "+partes[5]+"\n");
				txtMostrarStock.append("Rendimiento: "+partes[6]+"\n");
				txtMostrarStock.append("Tiempo de repintado: "+partes[7]+"\n");
				txtMostrarStock.append("Precio: S/."+partes[8]+"\n");
				txtMostrarStock.append("Tiempo de vida: "+partes[9]+"\n");
				txtMostrarStock.append("Cantidad: "+partes[10]+"\n");
				txtMostrarStock.append("\n");
				contador=contador+1;
			}
		}catch(IOException f){
			System.out.println("Error al guardar las pinturas.");
		}
		
	}
	public void mouseClicked(MouseEvent e) {
		if (e.getSource() == btnLimpiar) {
			mouseClickedBtnCerrar(e);
		}
	}
	public void mouseEntered(MouseEvent e) {
	}
	public void mouseExited(MouseEvent e) {
	}
	public void mousePressed(MouseEvent e) {
	}
	public void mouseReleased(MouseEvent e) {
	}
	protected void mouseClickedBtnCerrar(MouseEvent e) {
		txtMostrarStock.setText("");
	}
}
