package Logica;

import java.util.ArrayList;

public class Boleta {
	//variables
	public static ArrayList<String> codigos = new ArrayList<>();
	public static ArrayList<String> productos = new ArrayList<>();
	public static ArrayList<Double> preciosUnitarios = new ArrayList<>();
	public static ArrayList<Integer> cantidades = new ArrayList<>();
	public static ArrayList<Double> totales = new ArrayList<>();
	
	
}
