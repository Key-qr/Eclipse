package Logica;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class Descuento {
	//Variables
	public static double porcentaje0 = 0;
    public static double porcentaje1 = 5;
    public static double porcentaje2 = 10;
    public static double porcentaje3 = 15;
    
    //Nombre del archivo de propiedades, archivo donde se guardar�n los datos ingresados de descuentos
    private static final String ARCHIVO = "descuentos.properties";

    
    //Cargar los descuentos desde el archivo de propiedades
    public static void cargarDescuentos() {
        try {
            Properties props = new Properties();
            FileInputStream input = new FileInputStream("src/recursos/"+ARCHIVO);
            props.load(input);
            porcentaje0 = Double.parseDouble(props.getProperty("porcentaje0","0"));
            porcentaje1 = Double.parseDouble(props.getProperty("porcentaje1", "5"));
            porcentaje2 = Double.parseDouble(props.getProperty("porcentaje2", "10"));
            porcentaje3 = Double.parseDouble(props.getProperty("porcentaje3", "15"));
            input.close();
        } catch (IOException e) {
            System.out.println("No se pudo cargar el archivo de descuentos. Usando valores predeterminados.");
        }
    }
    
    
    //Guardar los descuentos en el archivo de propiedades
    public static void guardarDescuentos() {
        try {
            Properties props = new Properties();
            props.setProperty("porcentaje0", String.valueOf(porcentaje0));
            props.setProperty("porcentaje1", String.valueOf(porcentaje1));
            props.setProperty("porcentaje2", String.valueOf(porcentaje2));
            props.setProperty("porcentaje3", String.valueOf(porcentaje3));

            // Aqu� sobreescribe el archivo descuentos.properties
            FileOutputStream output = new FileOutputStream("src/recursos/"+ARCHIVO);
            props.store(output, "Descuentos guardados");
            output.close();
        } catch (IOException e) {
            System.out.println("Error al guardar los descuentos.");
        }
    }
    
    public static void restaurarValoresPorDefecto() {
    	porcentaje0 = 0;
        porcentaje1 = 5;
        porcentaje2 = 10;
        porcentaje3 = 15;
        guardarDescuentos(); // Guardamos los valores por defecto al archivo
    }
}
