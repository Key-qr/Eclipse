package Logica;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class Obsequio {
	
	//Variables
	public static String obsequio0 = "Sin Obsequio";
    public static String obsequio1 = "Brocha de 4";
    public static String obsequio2 = "Thiner de 2.8L";
    public static String obsequio3 = "Rodillo Profesional";
    
    //Nombre del archivo de propiedades, archivo donde se guardará los datos ingresados de descuentos
    private static final String ARCHIVO = "obsequios.properties";
    
    
    // Cargar los descuentos desde el archivo de propiedades
    public static void cargarObsequios() {
        try {
            Properties props = new Properties(); //Creamos el objeto props que interacturar� con el archivo obsequios.properties
            FileInputStream input = new FileInputStream("src/recursos/"+ARCHIVO); //Instanciamos el archivo en modo lectura
            props.load(input); //El m�todo load sirve para leer el contenido del archivo
            
            //Del archivo b�scame el valor de la llave "Obsequio0", si no hay nada, devu�lveme "Sin Obsequio"
            obsequio0 = props.getProperty("obsequio0", "Sin Obsequio");
            obsequio1 = props.getProperty("obsequio1", "Brocha de 4");
            obsequio2 = props.getProperty("obsequio2", "Thiner de 2.8L");
            obsequio3 = props.getProperty("obsequio3", "Rodillo Profesional");
            input.close(); //Aqu� cerramos el archivo, para evitar gastar recursos
        } catch (IOException e) {
            System.out.println("No se pudo cargar el archivo de descuentos. Usando valores predeterminados.");
        }
    }
    
    
    // Guardar los descuentos en el archivo de propiedades
    public static void guardarObsequios() {
        try {
            Properties props = new Properties(); //Creamos el objeto props que trabajar� al archivo obsequios.properties
            props.setProperty("obsequio0", obsequio0); //As�gnale a la clave "Obsequio0", lo que guarde en obsequio0
            props.setProperty("obsequio1", obsequio1);
            props.setProperty("obsequio2", obsequio2);
            props.setProperty("obsequio3", obsequio3);

            // Aqu� sobreescribe el archivo
            FileOutputStream output = new FileOutputStream("src/recursos/"+ARCHIVO);
            props.store(output, "Obsequios guardados");
            output.close();
        } catch (IOException e) {
            System.out.println("Error al guardar los obsequios.");
        }
    }
    
    public static void restaurarValoresPorDefecto() {
        obsequio0 = "Sin Obsequio";
        obsequio1 = "Brocha de 4";
        obsequio2 = "Thiner de 2.8L";
        obsequio3 = "Rodillo Profesional";
        guardarObsequios(); // Guardamos los valores por defecto al archivo
    }
    
}
