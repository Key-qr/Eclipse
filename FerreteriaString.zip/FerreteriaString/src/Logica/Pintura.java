package Logica;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

public class Pintura {
	int codigo, cantidad;
	String marca, color, tipo, acabado, presentacion, lavabilidad;
	double rendimiento, tiempoRepintado, precio, tiempoVida;
	
	private static final String ARCHIVO = "pinturas.properties";
	
	//M�todo constructor
	public Pintura(int codigo, int cantidad, String marca, String color, String tipo, String acabado,
			String presentacion, String lavabilidad, double rendimiento, double tiempoRepintado, double precio,
			double tiempoVida) {
		super();
		this.codigo = codigo;
		this.cantidad = cantidad;
		this.marca = marca;
		this.color = color;
		this.tipo = tipo;
		this.acabado = acabado;
		this.presentacion = presentacion;
		this.lavabilidad = lavabilidad;
		this.rendimiento = rendimiento;
		this.tiempoRepintado = tiempoRepintado;
		this.precio = precio;
		this.tiempoVida = tiempoVida;
	}
	
	//M�todos getters
	public int getCodigo() {
		return codigo;
	}

	public int getCantidad() {
		return cantidad;
	}

	public String getMarca() {
		return marca;
	}

	public String getColor() {
		return color;
	}

	public String getTipo() {
		return tipo;
	}

	public String getAcabado() {
		return acabado;
	}

	public String getPresentacion() {
		return presentacion;
	}

	public String getLavabilidad() {
		return lavabilidad;
	}

	public double getRendimiento() {
		return rendimiento;
	}

	public double getTiempoRepintado() {
		return tiempoRepintado;
	}

	public double getPrecio() {
		return precio;
	}

	public double getTiempoVida() {
		return tiempoVida;
	}
	
	
	public static void guardarPinturas() {
		ArrayList<Pintura> pinturas = new ArrayList<>();
		// American Colors (8 instancias)
        pinturas.add(new Pintura(1001, 50, "American Colors", "Blanco", "Latex", "Mate", "Galon", "Alta", 350, 24, 85.50, 60));
        pinturas.add(new Pintura(1002, 45, "American Colors", "Beige", "Latex", "Satinado", "Galon", "Alta", 330, 24, 89.90, 60));
        pinturas.add(new Pintura(1003, 30, "American Colors", "Azul cielo", "Acrilico", "Brillante", "Cuarto galon", "Media", 300, 36, 45.75, 48));
        pinturas.add(new Pintura(1004, 25, "American Colors", "Rojo", "Esmalte", "Brillante", "Galon", "Alta", 280, 48, 120.00, 72));
        pinturas.add(new Pintura(1005, 60, "American Colors", "Negro", "Latex", "Mate", "Galon", "Alta", 320, 24, 78.90, 60));
        pinturas.add(new Pintura(1006, 40, "American Colors", "Verde manzana", "Acrilico", "Satinado", "Galon", "Media", 310, 36, 92.50, 48));
        pinturas.add(new Pintura(1007, 35, "American Colors", "Gris perla", "Latex", "Satinado", "Cuarto galon", "Alta", 340, 24, 42.30, 60));
        pinturas.add(new Pintura(1008, 20, "American Colors", "Amarillo", "Esmalte", "Brillante", "Galon", "Alta", 290, 48, 115.75, 72));

        // CPP (8 instancias)
        pinturas.add(new Pintura(2001, 55, "CPP", "Blanco hueso", "Latex", "Mate", "Galon", "Alta", 360, 24, 82.40, 60));
        pinturas.add(new Pintura(2002, 40, "CPP", "Celeste", "Acrilico", "Satinado", "Galon", "Media", 320, 36, 88.90, 48));
        pinturas.add(new Pintura(2003, 30, "CPP", "Terracota", "Latex", "Mate", "Galon", "Alta", 340, 24, 95.20, 60));
        pinturas.add(new Pintura(2004, 25, "CPP", "Azul marino", "Esmalte", "Brillante", "Cuarto galon", "Alta", 280, 48, 50.60, 72));
        pinturas.add(new Pintura(2005, 50, "CPP", "Blanco puro", "Latex", "Satinado", "Galon", "Alta", 350, 24, 87.30, 60));
        pinturas.add(new Pintura(2006, 35, "CPP", "Lila", "Acrilico", "Mate", "Galon", "Media", 310, 36, 91.80, 48));
        pinturas.add(new Pintura(2007, 20, "CPP", "Naranja", "Esmalte", "Brillante", "Galon", "Alta", 270, 48, 125.00, 72));
        pinturas.add(new Pintura(2008, 45, "CPP", "Verde olivo", "Latex", "Mate", "Cuarto galon", "Alta", 330, 24, 40.90, 60));

        // Vencedor (8 instancias)
        pinturas.add(new Pintura(3001, 60, "Vencedor", "Blanco", "Latex", "Mate", "Galon", "Alta", 370, 24, 80.00, 60));
        pinturas.add(new Pintura(3002, 40, "Vencedor", "Cafe claro", "Latex", "Satinado", "Galon", "Alta", 340, 24, 92.50, 60));
        pinturas.add(new Pintura(3003, 30, "Vencedor", "Rosado", "Acrilico", "Mate", "Cuarto galon", "Media", 300, 36, 43.20, 48));
        pinturas.add(new Pintura(3004, 25, "Vencedor", "Plateado", "Esmalte", "Brillante", "Galon", "Alta", 260, 48, 135.00, 72));
        pinturas.add(new Pintura(3005, 50, "Vencedor", "Crema", "Latex", "Satinado", "Galon", "Alta", 350, 24, 89.90, 60));
        pinturas.add(new Pintura(3006, 35, "Vencedor", "Verde menta", "Acrilico", "Satinado", "Galon", "Media", 310, 36, 94.50, 48));
        pinturas.add(new Pintura(3007, 20, "Vencedor", "Dorado", "Esmalte", "Brillante", "Cuarto galon", "Alta", 250, 48, 55.80, 72));
        pinturas.add(new Pintura(3008, 45, "Vencedor", "Azul turquesa", "Latex", "Mate", "Galon", "Alta", 330, 24, 86.70, 60));

        // Tricolor (8 instancias)
        pinturas.add(new Pintura(4001, 55, "Tricolor", "Blanco", "Latex", "Mate", "Galon", "Alta", 365, 24, 81.30, 60));
        pinturas.add(new Pintura(4002, 40, "Tricolor", "Marfil", "Latex", "Satinado", "Galon", "Alta", 345, 24, 93.80, 60));
        pinturas.add(new Pintura(4003, 30, "Tricolor", "Vino", "Acrilico", "Mate", "Cuarto galon", "Media", 305, 36, 44.50, 48));
        pinturas.add(new Pintura(4004, 25, "Tricolor", "Bronce", "Esmalte", "Brillante", "Galon", "Alta", 275, 48, 130.50, 72));
        pinturas.add(new Pintura(4005, 50, "Tricolor", "Gris claro", "Latex", "Mate", "Galon", "Alta", 355, 24, 84.20, 60));
        pinturas.add(new Pintura(4006, 35, "Tricolor", "Verde bosque", "Acrilico", "Satinado", "Galon", "Media", 315, 36, 97.40, 48));
        pinturas.add(new Pintura(4007, 20, "Tricolor", "Cobre", "Esmalte", "Brillante", "Cuarto galon", "Alta", 265, 48, 52.90, 72));
        pinturas.add(new Pintura(4008, 45, "Tricolor", "Lavanda", "Latex", "Satinado", "Galon", "Alta", 335, 24, 91.00, 60));

        // Anypsa (8 instancias)
        pinturas.add(new Pintura(5001, 50, "Anypsa", "Blanco", "Latex", "Mate", "Galon", "Alta", 350, 24, 79.90, 60));
        pinturas.add(new Pintura(5002, 45, "Anypsa", "Champagne", "Latex", "Satinado", "Galon", "Alta", 330, 24, 88.70, 60));
        pinturas.add(new Pintura(5003, 30, "Anypsa", "Fucsia", "Acrilico", "Mate", "Cuarto galon", "Media", 290, 36, 41.80, 48));
        pinturas.add(new Pintura(5004, 25, "Anypsa", "Oro viejo", "Esmalte", "Brillante", "Galon", "Alta", 240, 48, 128.00, 72));
        pinturas.add(new Pintura(5005, 60, "Anypsa", "Blanco nieve", "Latex", "Mate", "Galon", "Alta", 360, 24, 83.50, 60));
        pinturas.add(new Pintura(5006, 40, "Anypsa", "Verde agua", "Acrilico", "Satinado", "Galon", "Media", 320, 36, 95.90, 48));
        pinturas.add(new Pintura(5007, 35, "Anypsa", "Plata", "Esmalte", "Brillante", "Cuarto galon", "Alta", 230, 48, 49.50, 72));
        pinturas.add(new Pintura(5008, 20, "Anypsa", "Melon", "Latex", "Satinado", "Galon", "Alta", 340, 24, 90.20, 60));

        // Sayer Lack (8 instancias)
        pinturas.add(new Pintura(6001, 55, "Sayer Lack", "Blanco", "Latex", "Mate", "Galon", "Alta", 370, 24, 86.40, 60));
        pinturas.add(new Pintura(6002, 40, "Sayer Lack", "Durazno", "Latex", "Satinado", "Galon", "Alta", 350, 24, 98.20, 60));
        pinturas.add(new Pintura(6003, 30, "Sayer Lack", "Esmeralda", "Acrilico", "Mate", "Cuarto galon", "Media", 310, 36, 47.80, 48));
        pinturas.add(new Pintura(6004, 25, "Sayer Lack", "Grafito", "Esmalte", "Brillante", "Galon", "Alta", 280, 48, 140.00, 72));
        pinturas.add(new Pintura(6005, 50, "Sayer Lack", "Blanco roto", "Latex", "Mate", "Galon", "Alta", 365, 24, 89.50, 60));
        pinturas.add(new Pintura(6006, 35, "Sayer Lack", "Turquesa", "Acrilico", "Satinado", "Galon", "Media", 325, 36, 102.30, 48));
        pinturas.add(new Pintura(6007, 20, "Sayer Lack", "Cromo", "Esmalte", "Brillante", "Cuarto galon", "Alta", 270, 48, 58.90, 72));
        pinturas.add(new Pintura(6008, 45, "Sayer Lack", "Limon", "Latex", "Satinado", "Galon", "Alta", 345, 24, 94.70, 60));

        // Sherwin-Williams (8 instancias)
        pinturas.add(new Pintura(7001, 50, "Sherwin-Williams", "Blanco", "Latex", "Mate", "Galon", "Alta", 380, 24, 120.00, 60));
        pinturas.add(new Pintura(7002, 45, "Sherwin-Williams", "Almendra", "Latex", "Satinado", "Galon", "Alta", 360, 24, 135.50, 60));
        pinturas.add(new Pintura(7003, 30, "Sherwin-Williams", "Zafiro", "Acrilico", "Mate", "Cuarto galon", "Media", 320, 36, 65.90, 48));
        pinturas.add(new Pintura(7004, 25, "Sherwin-Williams", "Oro", "Esmalte", "Brillante", "Galon", "Alta", 290, 48, 180.00, 72));
        pinturas.add(new Pintura(7005, 60, "Sherwin-Williams", "Blanco algodon", "Latex", "Mate", "Galon", "Alta", 390, 24, 125.80, 60));
        pinturas.add(new Pintura(7006, 40, "Sherwin-Williams", "Aguamarina", "Acrilico", "Satinado", "Galon", "Media", 340, 36, 145.20, 48));
        pinturas.add(new Pintura(7007, 35, "Sherwin-Williams", "Platino", "Esmalte", "Brillante", "Cuarto galon", "Alta", 300, 48, 75.40, 72));
        pinturas.add(new Pintura(7008, 20, "Sherwin-Williams", "Coral", "Latex", "Satinado", "Galon", "Alta", 370, 24, 138.90, 60));

        // Tekno (8 instancias)
        pinturas.add(new Pintura(8001, 55, "Tekno", "Blanco", "Latex", "Mate", "Galon", "Alta", 375, 24, 95.50, 60));
        pinturas.add(new Pintura(8002, 40, "Tekno", "Canela", "Latex", "Satinado", "Galon", "Alta", 355, 24, 108.70, 60));
        pinturas.add(new Pintura(8003, 30, "Tekno", "A�il", "Acrilico", "Mate", "Cuarto galon", "Media", 315, 36, 54.20, 48));
        pinturas.add(new Pintura(8004, 25, "Tekno", "Peltre", "Esmalte", "Brillante", "Galon", "Alta", 285, 48, 155.00, 72));
        pinturas.add(new Pintura(8005, 50, "Tekno", "Blanco perla", "Latex", "Mate", "Galon", "Alta", 380, 24, 99.90, 60));
        pinturas.add(new Pintura(8006, 35, "Tekno", "Jade", "Acrilico", "Satinado", "Galon", "Media", 335, 36, 115.80, 48));
        pinturas.add(new Pintura(8007, 20, "Tekno", "Cobre rosado", "Esmalte", "Brillante", "Cuarto galon", "Alta", 295, 48, 62.50, 72));
        pinturas.add(new Pintura(8008, 45, "Tekno", "Malva", "Latex", "Satinado", "Galon", "Alta", 365, 24, 105.40, 60));

        // Unicolor (8 instancias)
        pinturas.add(new Pintura(9001, 50, "Unicolor", "Blanco", "Latex", "Mate", "Galon", "Alta", 365, 24, 88.90, 60));
        pinturas.add(new Pintura(9002, 45, "Unicolor", "Avellana", "Latex", "Satinado", "Galon", "Alta", 345, 24, 96.50, 60));
        pinturas.add(new Pintura(9003, 30, "Unicolor", "Berengena", "Acrilico", "Mate", "Cuarto galon", "Media", 305, 36, 46.70, 48));
        pinturas.add(new Pintura(9004, 25, "Unicolor", "Lat�n", "Esmalte", "Brillante", "Galon", "Alta", 275, 48, 148.00, 72));
        pinturas.add(new Pintura(9005, 60, "Unicolor", "Blanco hueso", "Latex", "Mate", "Galon", "Alta", 375, 24, 92.80, 60));
        pinturas.add(new Pintura(9006, 40, "Unicolor", "Verde limon", "Acrilico", "Satinado", "Galon", "Media", 325, 36, 104.20, 48));
        pinturas.add(new Pintura(9007, 35, "Unicolor", "Oro rosa", "Esmalte", "Brillante", "Cuarto galon", "Alta", 285, 48, 56.30, 72));
        pinturas.add(new Pintura(9008, 20, "Unicolor", "Lila claro", "Latex", "Satinado", "Galon", "Alta", 355, 24, 98.60, 60));

        // Coral (8 instancias)
        pinturas.add(new Pintura(10001, 55, "Coral", "Blanco", "Latex", "Mate", "Galon", "Alta", 370, 24, 110.50, 60));
        pinturas.add(new Pintura(10002, 40, "Coral", "Caramelo", "Latex", "Satinado", "Galon", "Alta", 350, 24, 125.80, 60));
        pinturas.add(new Pintura(10003, 30, "Coral", "Azul petroleo", "Acrilico", "Mate", "Cuarto galon", "Media", 310, 36, 60.40, 48));
        pinturas.add(new Pintura(10004, 25, "Coral", "Antracita", "Esmalte", "Brillante", "Galon", "Alta", 280, 48, 175.00, 72));
        pinturas.add(new Pintura(10005, 50, "Coral", "Blanco natural", "Latex", "Mate", "Galon", "Alta", 380, 24, 115.90, 60));
        pinturas.add(new Pintura(10006, 35, "Coral", "Verde oscuro", "Acrilico", "Satinado", "Galon", "Media", 330, 36, 138.70, 48));
        pinturas.add(new Pintura(10007, 20, "Coral", "Bronce oscuro", "Esmalte", "Brillante", "Cuarto galon", "Alta", 290, 48, 70.20, 72));
        pinturas.add(new Pintura(10008, 45, "Coral", "Rosa palo", "Latex", "Satinado", "Galon", "Alta", 360, 24, 122.40, 60));
        
        String clave;
		String valor;
		Properties props = new Properties();
		
		try {
		    for(Pintura p: pinturas) {
		        clave = "pintura" + p.getCodigo();
		        valor = p.getMarca() + "," + p.getColor() + "," + p.getTipo() + "," +
	                       p.getAcabado() + "," + p.getPresentacion() + "," + p.getLavabilidad() + "," +
	                       p.getRendimiento() + "," + p.getTiempoRepintado() + "," + 
	                       p.getPrecio() + "," + p.getTiempoVida() + "," + p.getCantidad();
		        props.setProperty(clave, valor); 	
		        }

            // Aqu� sobreescribe el archivo descuentos.properties
            FileOutputStream output = new FileOutputStream("src/recursos/"+ARCHIVO);
            props.store(output, "pinturas guardadas");
            output.close();
		}catch (IOException e) {
            System.out.println("Error al guardar las pinturas.");
        }
	}
	
	public static void actualizarPinturas(ArrayList<Integer> codigos, ArrayList<Integer> cantidades) {
		//Aperturar el archivo
		Properties props = new Properties();
		String valor; //valor actual de la propiedad en el archivo pinturas.properties
		int cantidadActual; //La cantidad que figura en el archivo pinturas.properties
		int precioActual; //El precio que figura en el archivo pinturas.properties
		try {
			FileInputStream input = new FileInputStream("src/recursos/"+ARCHIVO);
			props.load(input);
			for(String clave :  props.stringPropertyNames()) {
				for(int i=0; i < codigos.size(); i++) {
					if(clave.equals("pintura"+codigos.get(i))) {
						//Accedemos al valor de la propiedad
						valor = props.getProperty(clave);
						String partes[] = valor.split(",");
						cantidadActual = Integer.parseInt(partes[10]);
						precioActual = Integer.parseInt(partes[8]);
						if(cantidadActual>cantidades.get(i)) {
							cantidadActual = cantidadActual - cantidades.get(i);
						}
					}
				}
			}
			
            FileOutputStream output = new FileOutputStream("src/recursos/"+ARCHIVO);
            props.store(output, "pinturas guardadas");
            output.close();
		}catch (IOException e) {
            System.out.println("Error al guardar las pinturas.");
        }
		//Buscar la clave
		//Modifcar la cantidad y precio
	}
	
	
	public static void cargarPinturas() {
		
        
	}
        
	//Por si las moscas
	/*public static void cargarProductos() {
        try {
            Properties props = new Properties();
            FileInputStream input = new FileInputStream("src/recursos/"+ARCHIVO);
            props.load(input);
            
            input.close();
        } catch (IOException e) {
            System.out.println("No se pudo cargar el archivo de pinturas.");
        }
    }
	
	public static void modificarCantidad() {
		
	}
	
	public static void modificarPrecio() {
		
	}*/
	
}
